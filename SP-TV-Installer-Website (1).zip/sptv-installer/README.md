# SP TV Installer — website starter

Premium, mobile-responsive Next.js homepage and multi-step booking flow, with Prisma-backed technician slots, Stripe deposit checkout, verified Stripe webhook confirmation, Resend confirmation email, customer booking status page, and password-protected admin dashboard.

## Quick start
1. Install Node.js 20+ and run `npm install`.
2. Copy `.env.example` to `.env` and fill in the keys. **Never commit `.env`.**
3. Run `npx prisma generate && npm run db:push && npm run db:seed`.
4. Run `npm run dev` and open http://localhost:3000. Admin: `/admin`.
5. For local Stripe webhooks: `stripe listen --forward-to localhost:3000/api/stripe/webhook` and put the resulting signing secret into `.env`.
6. Configure a verified sender domain in Resend and set `RESEND_API_KEY` and `EMAIL_FROM`.

## Architecture
- `/`: premium homepage
- `/book`: customer service selection, real-time available slot lookup, contact details, Stripe deposit checkout
- `/booking/[token]`: private customer status page
- `/admin`: password-protected operations dashboard and manual UTC slot publishing
- `GET /api/slots`: technician availability, excluding booked and blocked slots
- `POST /api/bookings`: validated booking and atomic slot reservation via unique slot relation; creates Stripe Checkout session
- `POST /api/stripe/webhook`: signature-verified payment confirmation, email trigger, expired-session cleanup
- `POST /api/admin/login`, `/api/admin/slots`: staff actions

## IMPORTANT: before production
This is a **working starter architecture**, not a production-certified scheduling service. Do not take live payments until the following are implemented and tested:
- Replace SQLite with hosted Postgres and use migrations for production hosting. Configure backups and logging.
- Implement timezone-aware scheduling by technician (currently demo slots are UTC and the UI displays local device time). Enforce working hours, travel buffers, geographic coverage, and daylight saving time.
- Implement expiry cleanup for abandoned pending bookings even if Stripe's webhook delivery fails, plus retry/reconciliation for delayed webhooks. The current webhook releases expired checkouts only when the event arrives.
- Improve admin auth to per-user accounts with MFA, rate limiting, CSRF defenses, and audit logs. Password login here is a starter only.
- Add email queue/retries, staff notifications, customer cancellation/reschedule, photo upload, privacy policy, terms, deposit/refund policy, and customer support details.
- Add actual installation photos licensed for commercial use. Current hero/service photography uses remote Unsplash Source URLs for visual placeholders and may not load reliably.
- Verify applicable taxes, payment processing, and consumer disclosure rules in both countries. Listed prices are illustrative and in CAD or USD depending on country.
- Add comprehensive unit, integration, webhook and end-to-end tests and monitor production errors.
- Customize cities, technician roster, branding, logo, contact details, domain, prices, and operating hours.

## Security notes
Stripe session success redirects are NOT treated as proof of payment; only verified webhooks confirm a booking. Customer status pages use unguessable access tokens. Do not expose admin secrets in client code. Admin password must be 16+ characters and ADMIN_SESSION_SECRET must be a different long random string.
